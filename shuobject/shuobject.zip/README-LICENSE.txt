The Shumway source code and resources are licensed under the Apache License,
Version 2.0. See LICENSE for details.

The Adobe Blank 2 font as used by Shumway is licensed under the SIL Open Font
License, Version 1.1. See LICENSE-OFL.txt for details.
